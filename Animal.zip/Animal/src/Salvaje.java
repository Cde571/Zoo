public class Salvaje {
    public abstract class Animal {
        protected boolean esSalvaje;

        public boolean esSalvaje() {
            return esSalvaje;
        }

        public abstract void hacerSonido();
    }

}


